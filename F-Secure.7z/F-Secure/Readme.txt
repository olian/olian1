==========================================================================
                   F-Secure SSH Client 5.4 Build 47
==========================================================================

F-Secure SSH Client is commercial software.

==========================================================================
                            New Features
==========================================================================
- 5.4 build 45
* Fixes sftp2 crash with ls command on batch mode (CTS#35677)
- 5.4 build 41
* Fixes for profile operations fail for redirected folders (CTS#35314)

- 5.4
* FIPS 140-2 level 2 validated crypto library that helps ensuring high level of security
* GSSAPI support to allow Windows kerberos authenticataion in Windows domains
* Connection ID support for tracking connections at the server side
* Multihop support for connecting through several SSH tunneling steps, stored in a single profile
* SFTP file transfer resume after a interrupted downloads
* Authentication Agent for safely storing private and public keys
* Possibility to connect to several SSH servers without entering a passphrase
* Using the same identity for additional SSH connections
* Unattended scheduled filetransfers

- 5.3 build 26
* Added chmod command to sftp2.exe
* Added compatibility against NetScreen ssh servers (CTS#31761)
* Fixed session logging (CTS#31790)
* Fixed filetransfer when source/destination is symbolic link (CTS#31760)
* sftp2 and scp2 exits correctly if server does not allow sftp connections

- 5.3 build 25
* Added supprt for illegal cursor position change
* fixed connect problems to localhost using real ip instead of 127.0.0.1 (CTS#30717)
* Added compatibility against Ericsson ssh servers 
* Fixed client crash when sftp server is unavailable (CTS#30716)

- 5.3 build 24
  30 day trial

- 5.3 build 23
* Fixes sftp2 problems with uppercase directory names (CTS#29487)
* Fixes sftp2 problems if there is no console (CTS#29363)
* Fixes problems when trying to add keyboard-interactive method
  into authentication method list (CTS#29296)
* Added compatibility code for VanDyke servers  (CTS#29657)

- 5.3 build 21
* Fixes ASN.1 vulnerabilities

- 5.3 build 20
* Fixes problems with sftp2 when there is not console (CTS#29363)
* Fixes missing keyboard-interactive authentication method from
  authentication page (CTS#29296)
  
- 5.3 build 19
* Fixes problems with pass-through printing

- 5.3 build 17
* Fixes password file problem with ssh2 (CTS#28856)
* Fixes -o option problems with scp2.exe and sftp2.exe

- 5.3 build 16
* Fixes publickey authentication problem with scp2 and sftp2 (CTS#28865)

- 5.3 build 15
  30 day trial
  
- 5.3 build 14
* Fixes problems with application to start feature (CTS#285)

- 5.3 build 13
  30 day trial
  
- 5.3 build 12
- Keyboard-interactive authentication method
- Socks 5 Proxy support
- XP look when running on XP
- Automatically minimize all windows after authentication
- Save layout

Graphical sftp
- Local pane
- Automatic sftp server type detector (win/unix)
- Sftp sent buffer number and size
- Local favorites
- New terminal/file transfer in current directory 
- Rename is now available in overwrite options
- Cutting (ctrl+x)
- Transfer queue

Tunneler
- Display name with tunnels
- Ftp support with remote tunnels

Command line clients
- Ctrl+c kills ssh2 is there is no session channel
- Sftp2 and Scp2 handles -k (keys dir) 
- Ssh2 accepts -i identityfile
- Ssh2 supports ANSI colors

Bug fixes
- Sftp2 ls -l filename works now (CTS#20333)
- Sftp2 and Scp2 returns correct error codes if connection fails (CTS#24425)
- Terminal reset required when working on OpenVMS  (CTS#25928)
- Ssh stream assert when closing xterm with Ssh1 protocol (CTS #26114)
- Passphrase is now asked 3 times (CTS#26384)

- 5.2 build 34
* Fixes qnx emulation problem with vi

- 5.2 build 33
* Fixed ascii transfer mode bug with large files

- 5.2 build 32
* Fixed connection problem with some VPN clients

- 5.2 build 31
* Added publickey fingerprints into User Keys page
* Sftp2 does not ask keypress when doing ls in batch mode
* Fixed X11 forwarding with ssh1 protocol
* Fixed file lock problem when aborting file transfer
* Fixed upload/download hanging when destination disk is full
* Fixed remote printing problem with Windows 9X

- 5.2 build 30
* Fixes crash with long lines (over 100000 characters)
* Fixes crash when cancelling new folder creation
* Allows to arrange favourites at any time

- 5.2 build 29
* Fixes stack overflow crash when closing active terminal window

- 5.2 build 28
* Fixes rename problem with File Transfer window
* Fixes file name problem with characters over 127 (ascii)

- 5.2 Build 23
* Added support to read user's password from a file to 
  command line applications (ssh2, scp2 and sftp2)
  
- 5.2 Build 21
* qnx terminal emulation support
* raw session logging
* fixed terminal size
* ssh2 supports now colors

- 5.2
* Microsoft Crypto Api support
* Keymap editor
* Publickey authentication method order
* Enable/disable 8-bit control characters
* Disable password length masking with ssh1 protocol
  (some ssh1 implementations requires this)
* Windows XP look
* Zlib 1.1.4 update

- 5.1
* PKI support
* SmartCard support
* Tunnel frame
* SSH Protocol 3.0 update
* SFTP favourites folders

- 5.0
* File Transfer, Key Registration Wizard and Key Generation Wizard are now
  included in F-Secure SSH Client
  
* Clone window feature - This feature allows for unlimited terminal and file 
  transfer windows over one connection.
  
* RSA SecurID - This feature offers a comprehensive range of authenticator 
  options, including hardware and software tokens for Palm Computing. 
  
* ssh-keygen2 command line tool

* Configurable connection profiles - This system allows Windows client users 
  to store each used connection as an easy-to-use "bookmark" and configure 
  the settings separately. The global variable SSHUSERDIR can be used to set
  the users' configuration directory
  
* Supports sending No-Operation packets once in a minute

* SSH Protocol 2.4 update
* Terminal
  - X11 style selection- When enabled, the selection will be copied 
    automatically to the clipboard

* Supported platforms: Windows 95 or Windows NT 4.0 or above

==========================================================================
                       Installation Instructions 
==========================================================================

* Installation

  Before starting the F-Secure SSH Client installation process, close 
  all running applications.

  If you receive the file fssh54b47.exe, simply double click the fssh54b47.exe
  file and follow the instructions of the setup program to install F-Secure SSH 
  Client on your computer.

  If you have a folder "disk1", double click the setup.exe file in that folder
  and follow the  instructions of the setup program to install F-Secure SSH
  Client on  your computer.
  
  The setup.exe program can also run in silent mode (setup -s). In the silent
  mode the setup program reads the installation instructions from prodsett.ini. 
  If you run setup.exe in silent mode the keycode must be provided in the 
  command line before the -s switch, or in the prodsett.ini file described
  below. These are the default settings if the file prodsett.ini is missing:

  [Silent Setup]   
  destinationDirUnderProgramFiles=F-Secure
  
  [SSHINST.DLL]
  FolderName=F-Secure SSH Client
  DestinationPath=Ssh
  AddToPath=Yes
  FolderType=common  
  AddDesktopShortcut=yes
    
  FolderType is only valid with Windows NT. Valid values are Common and Private.
  If it is something else, the folder type is common. 
  
  The keycode for F-Secure SSH Client setup can be provided in prodsett.ini as 
  follows:
 
  [F-Secure common]
  cd-key=keycode
  
  See section "Running F-Secure SSH" for more information on how to use
  F-Secure SSH.
 
==========================================================================
     Instructions for Users of Previous Versions 
==========================================================================

* Upgrading

  This version is compatible with all the previous F-Secure SSH 2.0 file 
  formats.
  
  We recommend using version 3.3.0 or later of the F-Secure SSH UNIX
  server for full compatibility and best performance.

* Client-Server Issues

  The TCP/IP forwarding code works properly only with version 2.0.12
  and later.

  We strongly recommend that you upgrade the UNIX server to version 3.3.0
  for best performance and compatibility between the UNIX and Windows 
  programs.

==========================================================================
                           Running F-Secure SSH
==========================================================================

* What do I need to run F-Secure SSH? 

  Microsoft Windows system and either a Local Area Network or an Internet connection
  before you can use F-Secure SSH. 

  To connect to a remote server, the server must be running an F-Secure SSH 
  Server for UNIX. This version is compatible with version 2.0.9 and 
  later. 

* Connecting to a Remote Host

  To connect to a remote computer using password authentication:

  1. In the Terminal or File Transfer window, press the Enter key

  2. In the Logon window, type the name of the remote host you
  want to connect to, and the user name for your account.

  3. From the authentication group, select Password as your authentication type.

  4. Choose the OK button.

  5. Type in the password for you account to the Connect Using Password 
  Authentication dialog box.

  7. Click OK or press Enter to connect.

  If this is the first time you are connecting to the host, F-Secure SSH Client
  may ask you to accept the host's previously unknown host key.

  NOTE: The quickest way to make the connection if your settings are 
  correct is to press the Enter key in an empty terminal window. This 
  will bring up the connection dialog box immediately.

* Getting Help

  See the F-Secure Client Help file for information on all F-Secure SSH 
  Features by pressing the Help button on one of the F-Secure SSH dialog boxes. 


==========================================================================
                               Copyrights
==========================================================================

* F-Secure SSH 

 Copyright (c) 1996-2004 F-Secure Corporation
 Copyright (c) 1995-2004 SSH Communications Security Corp.
 
 SSH is a registered trademark and Secure Shell is a trademark of 
 SSH Communications Security Corp (www.ssh.com).

